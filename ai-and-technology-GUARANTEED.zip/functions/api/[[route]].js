// API Routes para Cloudflare Pages Functions
export async function onRequest(context) {
  const { default: app } = await import('../../_worker.js');
  return app.fetch(context.request, context.env, context);
}