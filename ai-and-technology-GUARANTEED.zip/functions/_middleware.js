// Middleware para Cloudflare Pages Functions
export async function onRequest(context) {
  // Importa e executa o worker principal
  const { default: app } = await import('../_worker.js');
  
  // Cria o request para o Hono app
  return app.fetch(context.request, context.env, context);
}